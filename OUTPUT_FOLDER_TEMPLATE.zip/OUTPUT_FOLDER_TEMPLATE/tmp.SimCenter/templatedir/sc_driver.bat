"C:/Users/varun/Downloads/PBE_Windows_Download/PBE_Windows_Download/applications/performUQ/templateSub/simCenterSub.exe" params.in AIM.json.sc AIM.json
"C:/Users/varun/Downloads/PBE_Windows_Download/PBE_Windows_Download/applications/performUQ/templateSub/simCenterSub.exe" params.in EVENT.json.sc EVENT.json
call ./driver.bat

"C:/Users/varun/Downloads/PBE_Windows_Download/PBE_Windows_Download/applications/performUQ/common/extractEDP" EDP.json results.out
